#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "mpi.h"

//FUNCION QUE ASIGNA MEMORIA DINAMICA
int *imatrix(int rows, int cols) {
	int *matrix;
	matrix=(int *)malloc((rows)*(cols)*sizeof(int));
	return matrix;
}
//FUNCION QUE IMPRIME MATRIZ
void print_matrix(int* matrix, int rows, int cols) {
    int i, j;     
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            printf("[%d]  ", *(matrix + i * cols + j));
            //printf("[%d]  ", matrix[i * cols + j]);
        }
    	printf("\n");
   	}
    printf("\n");
}
//FUNCION QUE RELLENA LA MATRIZ CON NUMEROS ALEATORIOS ENTRE 1 a 999
void fill_matrix(int *matrix, int rows, int cols) {
	int i=0, j=0;
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            *(matrix + i * cols + j) = 1 + rand() % 999;
        }
    }	
}
//FUNCION QUE BUSCA EL VALOR MINIMO EN UN MATRIZ
int par_min_matrix(int *matrix, int rows, int cols) {
    int min = 9999999;
    int i=0, j=0;
    //printf("RANK:%d, SIZE:%d, rows:%d, cols:%d\n",rank,size,rows,cols);
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            if (*(matrix + i * cols + j) < min) {
                min = *(matrix + i * cols + j);
            }
            //printf("(%d)  ", *(matrix + i * cols + j));
        }
        //printf("\n");
    }
    return min;
}


int main(int argc, char** argv) { // argc y argv se usan para pasar informacion por linea de comandos
    int *A; 
    int n;
    int rank, size; // identificador del proceso, Cantidad de procesos
    int local_min;
    int global_min;
    double end_time;
    double elapsed_time;
    double start_time;
    // Inicializamos MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    if(argc != 2) { // numero de argumentos
        printf("ERROR %s n\n", argv[0]);
        return 1;
    }

    n = atoi(argv[1]); //atoi transforma de string a entero
    srand(time(0)); //No repetir los mismos numeros aleatorios en cada ejecucion

    //ASIGNAMOS MEMORIA DINAMICA SOLO AL PROCESO MAESTRO
    if(rank == 0) {
    	A = imatrix(n, n);
    	if(A == NULL) {
        	printf("Error de reserva de espacio");
        	return 1;
    	}
    	fill_matrix(A, n, n);
    	//print_matrix(A, n, n);
    }
    // ASIGNAMOS MEMORIA DINAMICA A TODOS LOS PROCESOS
	int rows_per_process = n / size;
	int *local_A = imatrix(rows_per_process, n);
	if(local_A == NULL) {
    	printf("Error de reserva de espacio");
    	MPI_Finalize();
    	return 1;
	}
	//INICIO TIEMPO
	if(rank == 0){
        start_time = MPI_Wtime();
    }
	// DISTRIBUIMOS LA MATRIZ ENTRE LOS PROCESOS
	MPI_Scatter(A, rows_per_process * n, MPI_INT, local_A, rows_per_process * n, MPI_INT, 0, MPI_COMM_WORLD);
	//print_matrix(local_A, rows_per_process, n);

	// BUSQUEDA DEL MINIMO DE LA MATRIZ DE FORMA PARALELA
	local_min = par_min_matrix(local_A, rows_per_process, n);
	printf("MINIMO LOCAL DE EL PROCESADOR:%d, ES:%d\n",rank,local_min);
	// REDUCCION DEL MINIMO GLOBAL DE LA MATRIZ
	MPI_Reduce(&local_min, &global_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);
	
	if(rank == 0) {
    	printf("El valor minimo de la matriz es: %d\n", global_min);
    	end_time = MPI_Wtime();
        elapsed_time = end_time - start_time;
        printf("Tiempo de operacion:%f\n",elapsed_time);
	}
	if(rank == 0) {
	    free(A);
	}
	free(local_A);
	MPI_Finalize();

    return 0;
}
