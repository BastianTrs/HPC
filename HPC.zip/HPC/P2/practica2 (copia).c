#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "mpi.h"

//FUNCION QUE ASIGNA MEMORIA DINAMICA
int *imatrix (int rows, int cols) {
	int *matrix;
	matrix=(int *)malloc((rows)*(cols)*sizeof(int));
	return matrix;
}
//FUNCION QUE IMPRIME MATRIZ
void print_matrix(int* matrix, int rows, int cols) {
    int i, j;     
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("[%d]  ", *(matrix + i * cols + j));
        }
    	printf("\n");
   	}
    printf("\n");
}
//FUNCION QUE RELLENA LA MATRIZ CON NUMEROS ALEATORIOS ENTRE 1 a 999
void fill_matrix(int *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            *(matrix + i * cols + j) = 1 + rand() % 999;
        }
    }	
}
//FUNCION SECUENCIAL QUE RETORNA EL VALOR MAS PEQUEÑO DE UNA MATRIZ
void sec_min_matrix(int *matrix, int rows, int cols) {	
    int min;
    min = *(matrix + 0 * cols + 0);
    printf("[%d]\n", min);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
        	if(*(matrix + i * cols + j) < min) 
            	min = *(matrix + i * cols + j);
        }
    }
    printf("[%d]\n", min);
}

int par_min_matrix(int *matrix, int rows, int cols, int rank, int size) {
    int min = 1000;
    int i=0, j=0;
    int iter=0;
    printf("min inicial:%d\n",min);
    printf("RANK:%d, SIZE:%d, rows:%d, cols:%d\n",rank,size,rows,cols);
    for (i = 0; i < (rows / size); i++) {
        for (j = 0; j < cols; j++) {
        	iter++;
            if (*(matrix + i * cols + j) < min) {
                min = *(matrix + i * cols + j);
            }
            //printf("(%d)  ", *(matrix + i * cols + j));
        }
        //printf("\n");
    }
    printf("iteraciones:%d\n",iter);
    printf("min final:%d\n",min);
    return min;
}


int main(int argc, char** argv) { // argc y argv se usan para pasar informacion por linea de comandos
    int *A; 
    int n; // tamaño matriz
    int i, j;
    int rank, size; // numero de procesos, identificador del proceso
    int min;
    int global_min;
    // Inicializamos MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    clock_t start, end;
    if (argc != 2) { // numero de argumentos
        printf("ERROR %s n\n", argv[0]);
        return 1;
    }

    n = atoi(argv[1]); //atoi transforma de string a entero
    srand(time(0)); //No repetir los mismos numeros aleatorios en cada ejecucion

    //ASIGNAMOS MEMORIA DINAMICA SOLO AL PROCESO MAESTRO
    if (rank == 0) {
    	A = imatrix(n, n);
    	if (A == NULL) {
        	printf("Error de reserva de espacio");
        	return 1;
    	}
    	fill_matrix(A, n, n);
    	//print_matrix(A, n, n);
    }

    // ASIGNAMOS MEMORIA DINAMICA A TODOS LOS PROCESOS
	int rows_per_process = n / size;
	int *local_A = imatrix(rows_per_process, n);
	if (local_A == NULL) {
    	printf("Error de reserva de espacio");
    	MPI_Finalize();
    	return 1;
	}
	//print_matrix(local_A, rows_per_process, n);
	//INICIO TIEMPO
    double start_time = MPI_Wtime();
	// DISTRIBUIMOS LA MATRIZ ENTRE LOS PROCESOS
	MPI_Scatter(A, rows_per_process * n, MPI_INT, local_A, rows_per_process * n, MPI_INT, 0, MPI_COMM_WORLD);
	//print_matrix(local_A, rows_per_process, n);

	// BUSQUEDA DEL MINIMO DE LA MATRIZ DE FORMA PARALELA
	min = par_min_matrix(local_A, n, n, rank, size);
	printf("MINIMO LOCAL DE EL PROCESADOR:%d, ES:%d\n",rank,min);
	// REDUCCION DEL MINIMO GLOBAL DE LA MATRIZ
	MPI_Reduce(&min, &global_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);

	//FIN TIEMPO
	double end_time = MPI_Wtime();
    double elapsed_time = end_time - start_time;
    printf("Tiempo de operacion:%f\n",elapsed_time);
    	
    // IMPRIMIMOS EL MINIMO GLOBAL
	if (rank == 0) {
    	printf("El valor minimo de la matriz es: %d\n", global_min);
	}
	// LIBERAMOS LA MEMORIA
	if (rank == 0) {
	    free(A);
	}
	free(local_A);

	// Finalizamos MPI
	MPI_Finalize();

    
    return 0;
}
