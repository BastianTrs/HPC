#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//FUNCION QUE ASIGNA MEMORIA DINAMICA
int *imatrix (int rows, int cols) {
	int *matrix;
	matrix=(int *)malloc((rows)*(cols)*sizeof(int));
	return matrix;
}
//FUNCION QUE IMPRIME MATRIZ
void print_matrix(int* matrix, int rows, int cols) {
    int i, j;     
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("[%d]  ", *(matrix + i * cols + j));
        }
    	printf("\n");
   	}
    printf("\n");
}
//FUNCION QUE RELLENA LA MATRIZ CON NUMEROS ALEATORIOS ENTRE 1 a 99
void fill_matrix(int *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            *(matrix + i * cols + j) = 1 + rand() % 99;
        }
    }	
}
//FUNCION SECUENCIAL QUE RETORNA EL VALOR MAS PEQUEÑO DE UNA MATRIZ
void sec_min_matrix(int *matrix, int rows, int cols) {	
    int min;
    min = *(matrix + 0 * cols + 0);
    //printf("[%d]\n", min);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
        	if(*(matrix + i * cols + j) < min) 
            	min = *(matrix + i * cols + j);
        }
    }
    //printf("[%d]\n", min);
}

int main(int argc, char** argv) { // argc y argv se usan para pasar informacion por linea de comandos
    int *A; 
    int n; // tamaño matriz
    int i, j;
    int np, mid; // numero de procesos, identificador del proceso
    
    clock_t start, end;
    if (argc != 2) { // numero de argumentos
        printf("ERROR %s n\n", argv[0]);
        return 1;
    }

    n = atoi(argv[1]); //atoi transforma de string a entero
    srand(time(NULL)); //No repetir los mismos numeros aleatorios en cada ejecucion

    //ASIGNAMOS MEMORIA DINAMICA
    A = imatrix(n,n);
    if (A == NULL) {
    	printf("Error de reserva de espacio");
    }
    
    //print_matrix(A,n,n);
    fill_matrix(A,n,n);
    //print_matrix(A,n,n);
    
    //TIEMPO
    start = clock();
    
    sec_min_matrix(A,n,n);
    
    end = clock();
    double time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Tiempo de operacion:%f\n",time);
    
    //LIBERAMOS MEMORIA DINAMICA
    free(A);
    return 0;
}
