#include <stdio.h>
#include <stdlib.h>
#include <time.h>


//Funcion que rellena la matriz con numeros aleatorios entre 0 a 9
void fillMatrix(int **matrix, int ROWS, int COLS) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            matrix[i][j] = rand() % 10;
        }
    }
}
//Funcion que rellena la matrix con 0
void zeroMatrix(int **matrix, int ROWS, int COLS) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            matrix[i][j] = 0;
        }
    }
}
void print_matrix(int** matrix, int ROWS, int COLS) {
    int i, j;
    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            printf("[%d]", matrix[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char** argv) { // argc y argv se usan para pasar informacion por linea de comandos
    int ROWS, COLS;
    int **A, **B, **C;
    int i, j, k;
    clock_t start, end;
    if (argc < 3) { // el numero de argumentos
        printf("ERROR Uso: %s ROWS COLS\n", argv[0]);
        return 1;
    }

    ROWS = atoi(argv[1]); //atoi transforma de string a entero
    COLS = atoi(argv[2]);

    srand(time(NULL)); 

    //ASIGNAMOS MEMORIA DINAMICA
    A = (int**)malloc(ROWS * sizeof(int*));
    for (int i = 0; i < ROWS; i++) {
        A[i] = (int*)malloc(COLS * sizeof(int));
    }

    B = (int**)malloc(ROWS * sizeof(int*));
    for (int i = 0; i < ROWS; i++) {
        B[i] = (int*)malloc(COLS * sizeof(int));
    }
    C = (int**)malloc(ROWS * sizeof(int*));
    for (int i = 0; i < ROWS; i++) {
        C[i] = (int*)malloc(COLS * sizeof(int));
    }

    fillMatrix(A,ROWS,COLS);
    fillMatrix(B,ROWS,COLS);
    
    
    //print_matrix(A,ROWS,COLS);
    //printf("\n");
    //print_matrix(B,ROWS,COLS);
    
    
    //CALCULO DEL PRODUCTO DE MATRICES
    //ijk
    start = clock();
    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            for (k = 0; k < COLS; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    end = clock();
    double time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Tiempo de operacion ijk:%f\n",time);
    //print_matrix(C,ROWS,COLS);
    //printf("\n");
    
    zeroMatrix(C,ROWS,COLS);

    //jki
    start = clock();
    for (j = 0; j < COLS; j++) {
        for (k = 0; k < COLS; k++) {
            for (i = 0; i < ROWS; i++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    end = clock();
    time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Tiempo de operacion jki:%f\n",time);
    //print_matrix(C,ROWS,COLS);
    //printf("\n");
    
    zeroMatrix(C,ROWS,COLS);
    
    //kji
    start = clock(); 
    for (k = 0; k < COLS; k++) {
        for (j = 0; j < COLS; j++) {
            for (i = 0; i < ROWS; i++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    end = clock();
    time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Tiempo de operacion kji:%f\n",time);
    
    //printf("\n");
    //print_matrix(C,ROWS,COLS);
    
   
    //LIBERAMOS MEMORIA DINAMICA
    for (int i = 0; i < ROWS; i++) {
        free(A[i]);
        free(B[i]);
        free(C[i]);
    }
    free(A);
    free(B);
    free(C);

    return 0;
}
