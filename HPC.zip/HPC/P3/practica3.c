#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include <omp.h>

//FUNCION QUE ASIGNA MEMORIA DINAMICA
int *imatrix(int rows, int cols) {
	int *matrix;
	matrix=(int *)malloc((rows)*(cols)*sizeof(int));
	return matrix;
}
//FUNCION QUE IMPRIME MATRIZ
void print_matrix(int* matrix, int rows, int cols) {
    int i, j;     
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            printf("[%d]  ", *(matrix + i * cols + j));
            //printf("[%d]  ", matrix[i * cols + j]);
        }
    	printf("\n");
   	}
    printf("\n");
}
//FUNCION QUE RELLENA LA MATRIZ CON NUMEROS ALEATORIOS ENTRE 1 a 990
void fill_matrix(int *matrix, int rows, int cols) {
	int i=0;
	int j=0;
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            matrix[i * cols + j] = 1 + rand() % INT_MAX;
        }
    }	
}
//FUNCION QUE BUSCA EL VALOR MINIMO EN UN MATRIZ
int par_min_matrix(int *matrix, int rows, int cols, int thread) {
    int min = matrix[thread * rows * cols];
    //printf("minimo inicial:%d\n",min);
    int i=0, j=0;
    for(i = thread * rows; i < (thread + 1)* rows; i++) {
        for(j = 0; j < cols; j++){
            if(matrix[i * cols + j] < min){
                min = matrix[i * cols + j];
            }
            //printf("(%d) ", *(matrix + i * cols + j));
        }
        //printf("\n");
    }
    return min;
}

int main(int argc, char** argv) { // argc y argv se usan para pasar informacion por linea de comandos
	
   int *A;    
   int n;
   int local_min = INT_MAX;
   int global_min = INT_MAX;
   int rows_per_thread;
   int threads;
   int thread_id;
	int row_start;
   double start_time, end_time, elapsed_time;
    
   if(argc != 2) { // numero de argumentos
       printf("ERROR---> %s n \n", argv[0]);
       return 1;
   }

   n = atoi(argv[1]); 
   threads = omp_get_max_threads();
   A = imatrix(n, n);
   if(A == NULL) {
       printf("Error de reserva de espacio");
       return 1;
   }
   fill_matrix(A, n, n);
   //print_matrix(A, n, n);
	 
	rows_per_thread = n / threads;
   printf("n:%d threads:%d rows_per_thread:%d \n",n, threads,rows_per_thread);
	start_time = omp_get_wtime();

	#pragma omp parallel num_threads(threads) private(local_min,thread_id)
	{
		thread_id = omp_get_thread_num();
		row_start = thread_id * rows_per_thread;
		printf("thread_id:%d row_start:%d\n",thread_id,row_start);
		local_min = par_min_matrix(A,rows_per_thread,n,thread_id);
		printf("local_min: %d\n", local_min);
		#pragma omp critical
      {
            if (local_min < global_min) {
                global_min = local_min;
            }
      }
	}
	
	end_time = omp_get_wtime();
   elapsed_time = end_time - start_time;
   printf("Tiempo de operacion:%f\n",elapsed_time);
   printf("global_min: %d\n", global_min);
	free(A);

    return 0;
}
