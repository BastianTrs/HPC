#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#define NUM_THREADS 2

//FUNCION QUE ASIGNA MEMORIA DINAMICA
int *imatrix(int rows, int cols) {
	int *matrix;
	matrix=(int *)malloc((rows)*(cols)*sizeof(int));
	return matrix;
}
//FUNCION QUE IMPRIME MATRIZ
void print_matrix(int* matrix, int rows, int cols) {
    int i, j;     
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            printf("[%d]  ", *(matrix + i * cols + j));
            //printf("[%d]  ", matrix[i * cols + j]);
        }
    	printf("\n");
   	}
    printf("\n");
}
//FUNCION QUE RELLENA LA MATRIZ CON NUMEROS ALEATORIOS ENTRE 1 a 99
void fill_matrix(int *matrix, int rows, int cols) {
	int i=0;
	int j=0;
    for(i = 0; i < rows; i++) {
        for(j = 0; j < cols; j++) {
            *(matrix + i * cols + j) = 1 + rand() % 99;
        }
    }	
}
//FUNCION QUE BUSCA EL VALOR MINIMO EN UN MATRIZ
int par_min_matrix(int *matrix, int rows, int cols, int thread, int size) {
    int min = 9999999;
    int i=0, j=0;
    int pos;
    if(thread == 0) pos == 0;
    else{
    	pos = (thread * size);
    }
    for(i = pos; i < size * (thread + 1); i++) {
        for(j = 0; j < cols; j++) {
            if(*(matrix + i * cols + j) < min) {
                min = *(matrix + i * cols + j);
            }
            printf("(%d)  ", *(matrix + i * cols + j));
        }
        printf("\n");
    }
    return min;
}


int main(int argc, char** argv) { // argc y argv se usan para pasar informacion por linea de comandos
    int *A; 
    int n;
    int min= 999999999;
    int local_min;
    int global_min;
    int rows_per_thread;
    int threads = NUM_THREADS;
    double start_time, end_time, elapsed_time;
    
    if(argc != 2) { // numero de argumentos
        printf("ERROR %s n\n", argv[0]);
        return 1;
    }

    n = atoi(argv[1]); //atoi transforma de string a entero

    A = imatrix(n, n);
    if(A == NULL) {
        printf("Error de reserva de espacio");
        return 1;
    }
    fill_matrix(A, n, n);
    print_matrix(A, n, n);
    
    //Quitar / Mover 
    int i,j;	
	int rows = n;
	int cols = n;
	rows_per_thread = n / threads;
    
	start_time = omp_get_wtime();

	#pragma omp parallel num_threads(2) shared(A, rows, cols, min, rows_per_thread) private(i, j)
	{
		#pragma omp for
		for(i = rows_per_thread * omp_get_thread_num(); i < rows_per_thread * (omp_get_thread_num() + 1); i++){
    		for(j = 0; j < cols; j++) {
    		    printf("id=%d i=%d ",omp_get_thread_num(),i);
    			//printf("%d(%d)  ", omp_get_thread_num(), *(A + i * cols + j));
        		if(*(A + i * cols + j) < min) {
            		#pragma omp critical
            		{
                		if (*(A + i * cols + j) < min) {
                    		min = *(A + i * cols + j);
                		}
            		}
        		}
    		}
    	printf("\n");
		}
	}
	//global_min = par_min_matrix(A, n, n, 0, n);
	
	end_time = omp_get_wtime();
    elapsed_time = end_time - start_time;
    printf("Tiempo de operacion:%f\n",elapsed_time);
    printf("El valor minimo de la matriz es: %d\n", min);
    //printf("El valor minimo de la matriz es: %d\n", global_min);
	free(A);

    return 0;
}
